if (!(typeof App !== "undefined" && App !== null)) {
  window.App = {};
}
;
