/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.editorConfig=function(a){a.uiColor="#AADC6E";a.extraPlugins="wordcount";a.wordcount={showParagraphs:!1,showWordCount:!1,showCharCount:!0,countSpacesAsChars:!1,countHTML:!1,maxWordCount:-1,maxCharCount:-1}};
