/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('wordcount', 'pt-br', {
    WordCount: 'Contagem de palavras:',
    CharCount: 'Contagem de carateres:',
    CharCountWithHTML: 'Carateres (incluindo HTML):',
    Paragraphs: 'Parágrafos:',
    pasteWarning: 'Conteúdo não pode ser colado porque ultrapassa o limite permitido',
    Selected: 'Selecionado: ',
    title: 'Estatísticas'
});
